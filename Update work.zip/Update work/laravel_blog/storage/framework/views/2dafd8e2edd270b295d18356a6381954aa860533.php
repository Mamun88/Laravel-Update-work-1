<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
       
        <div class="col-md-12">
           <div class="card">
            <div class="card-header" style="background: #282923; color: #fff; text-align: center;">Product Inserted View</div>
                  <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                <div class="card-body">
                <table class="table table-bordered">
					  <thead>
					    <tr>
					      <th scope="col">Product Name</th>
					      <th scope="col">Product Summary</th>
					      <th scope="col">Product Description</th>
					      <th scope="col">Product Price</th>
					      <th scope="col">Product Quantity</th>
					      <th scope="col">Alert Quantity</th>
					      <th scope="col">Product Image</th>
					      <th scope="col">Update</th>
					      <th scope="col">Delete</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					    <tr>
					      <td><?php echo e($value->product_name); ?></td>
					      <td><?php echo e(Str::limit($value->product_summary, 80)); ?></td>
					      <td><?php echo e(Str::limit($value->product_description, 80)); ?></td>
					      <td><?php echo e($value->product_price); ?></td>
					      <td><?php echo e($value->product_quantity); ?></td>
					      <td><?php echo e($value->alert_quantity); ?></td>
					      <td><img src="<?php echo e(Storage::url($value->product_image)); ?>" hight='50' width="50"></td>
					      <td>
					      <a class="btn btn-outline-success" href="<?php echo e(url('/product/edit',$value->id)); ?>">Edit</a>
					      </td>
					      <td>
					      	<form action="<?php echo e(url('/product/delete',$value->id)); ?>" method="post">
					      		<?php echo csrf_field(); ?>
					      		<button class="btn btn-outline-danger">Delete</button>
					      	</form>
					      </td>
					    </tr>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					    <p>No Data Available</p>
					   <?php endif; ?>
					  </tbody>
					</table>
					<?php echo e($products->links()); ?>


                
                  
                    
                </div>
           
           <div class="card-header" style="background: #575c62; color: #fff; text-align: center;">Product Restore View</div>
                  <?php if(session('restore')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('restore')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('parmanentdelete')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('parmanentdelete')); ?>

                        </div>
                    <?php endif; ?>
                <div class="card-body">
                <table class="table table-bordered">
					  <thead>
					    <tr>
					      <th scope="col">Product Name</th>
					      <th scope="col">Product Summary</th>
					      <th scope="col">Product Description</th>
					      <th scope="col">Product Price</th>
					      <th scope="col">Product Quantity</th>
					      <th scope="col">Alert Quantity</th>
					      <th scope="col">Product Image</th>
					      <th scope="col">Update</th>
					      <th scope="col">Delete</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php $__empty_1 = true; $__currentLoopData = $restored; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					    <tr>
					      <td><?php echo e($value->product_name); ?></td>
					      <td><?php echo e(Str::limit($value->product_summary, 80)); ?></td>
					      <td><?php echo e(Str::limit($value->product_description, 80)); ?></td>
					      <td><?php echo e($value->product_price); ?></td>
					      <td><?php echo e($value->product_quantity); ?></td>
					      <td><?php echo e($value->alert_quantity); ?></td>
					      <td><img src="<?php echo e(Storage::url($value->product_image)); ?>" hight='50' width="50"></td>
					      <td>
					      <a class="btn btn-danger" href="<?php echo e(url('/product/parmanentdelete',$value->id)); ?>">Permanently Deleting</a>
					      </td>
					      <td>
					      	<form action="<?php echo e(url('/product/restore',$value->id)); ?>" method="post">
					      		<?php echo csrf_field(); ?>
					      		<button class="btn btn-outline-primary">Restore</button>
					      	</form>
					      </td>
					    </tr>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					    <p>No Data Available</p>
					   <?php endif; ?>
					  </tbody>
					</table>
					<?php echo e($products->links()); ?>


                
                  
                    
                </div>
            </div>
        </div>


       
    
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\laravel_blog\resources\views/backend/product.blade.php ENDPATH**/ ?>