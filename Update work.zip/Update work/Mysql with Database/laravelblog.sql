-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2019 at 05:11 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravelblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(8, '2019_07_13_144704_create_products_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_summary` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `alert_quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'noimage.png',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_summary`, `product_description`, `product_price`, `product_quantity`, `alert_quantity`, `product_image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'Easey fashion', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date...', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date...', 7005, 50, '5', 'noimage.png', '2019-08-24 02:12:44', '2019-08-25 03:49:07', '2019-08-25 03:49:07'),
(3, 'alixpress fashion house', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 4775, 50, '5', 'noimage.png', '2019-08-24 02:15:44', '2019-09-04 23:15:46', '2019-09-04 23:15:46'),
(4, 'daraz fashion', 'will be Found here very first. If You Come To Search F Result 2019', 'will be Found here very first. If You Come To Search F Result 2019', 22675, 50, '5', 'noimage.png', '2019-08-24 02:23:41', '2019-08-25 03:44:08', NULL),
(5, 'daraz fashion', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 22675, 50, '5', 'noimage.png', '2019-08-24 02:38:23', '2019-09-04 23:51:27', NULL),
(6, 'Easey fashion', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 22675, 60, '10', 'noimage.png', '2019-08-24 02:38:40', '2019-08-25 03:44:08', NULL),
(7, 'Easey fashion', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 'will be Found here very first. If You Come To Search F Result 2019 Publish Date', 22675, 50, '5', 'noimage.png', '2019-08-24 02:38:54', '2019-08-25 03:44:08', NULL),
(11, 'MAMAUN fashion', 'a web application framework with expressive, elegant a web a web application framework with expressive, elegant a web', 'a web application framework with expressive, elegant a web a web application framework with expressive, elegant a web a web application framework with expressive, elegant a web', 700, 60, '10', 'noimage.png', '2019-08-25 03:14:50', '2019-09-05 00:25:12', NULL),
(18, 'daraz fashion', 'here are a few important things to note about this example. Note that we only', 'here are a few important things to note about this example. Note that we only specified a directory name, not a file name. By default, the store method will generate a unique ID to serve as the file name', 5345, 244, '34', 'noimage.png', '2019-09-05 01:09:02', NULL, NULL),
(19, 'MAMAUN fashion', 'here are a few important things to note about this example. Note that we only specif name', 'here are a few important things to note about this example. Note that we only specified a directory name, not a file name. By default, the store method will generate a unique ID to serve as the file name', 32445, 244, '34', 'noimage.png', '2019-09-05 01:13:22', NULL, NULL),
(20, 'MAMAUN fashion', 'about this example. Note that we only specified a directory name, not a file name. By default, the store method will generate a unique ID to serve as the file name', 'There are a few important things to note about this example. Note that we only specified a directory name, not a file name. By default, the store method will generate a unique ID to serve as the file name', 32445, 244, '34', 'public/product_images/iOWCRigEczX887FIFQh17UszExPp3mz1njZz6llZ.jpeg', '2019-09-05 01:17:22', NULL, NULL),
(21, 'Sumon fashion', 'sometimes known, is dummy text used in laying out print, graphic or web designs', 'sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero', 32445, 244, '34', 'noimage.png', '2019-09-05 01:50:57', NULL, NULL),
(22, 'sojib fashion', 'sometimes known, is dummy text used in laying out print, graphic or web designs.', 'sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero', 32445, 244, '24', 'public/product_images/Zx1AYZNfcHC9uW4Sw5FKoRgcBJ2vvDqQf27RGu7A.png', '2019-09-05 01:52:03', NULL, NULL),
(23, 'daraz fashion', 'Is dummy text used in laying out print, graphic or web designs. The passage is attributed', 'Is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s', 32445, 244, '34', 'public/product_images/IkkGepGV7qACoFZFC3I48Ic63a04gDBTEksRpnpN.jpeg', '2019-09-05 02:02:12', '2019-09-05 03:06:43', '2019-09-05 03:06:43');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Abdullah Al Mamun', 'mamuncet27@gmail.com', '2019-07-15 07:00:00', '$2y$10$cl.ggqwa2Bz0Z8lRwtXXGOM8xSGuOEUh/GCfp6i9X3fkaxMQ4.Fqe', 'E1GRzbWVhoys0PD80Zhv1bnqzKYm4bRQMTpUIMOgqhJewp10Ztlag5lW2QoL', '2019-07-12 23:17:48', '2019-07-12 23:17:48'),
(2, 'Abdullah Al Mamun', 'mamuncreativeit@gmail.com', NULL, '$2y$10$jEEQimBnftTvGZxZjED18OsX38riZia6VWsxU2ub4ztpXtAltRQoS', NULL, '2019-07-26 15:58:18', '2019-07-26 15:58:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
